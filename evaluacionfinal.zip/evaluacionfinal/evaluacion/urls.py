from django.contrib import admin
from django.urls import path
from core import views

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),

    # Inicio
    path('', views.home, name='home'),

    # Categorías
    path('categorias/', views.categorias_lista, name='categorias_lista'),
    path('categorias/nueva/', views.categoria_crear, name='categoria_crear'),
    path('categorias/<int:pk>/editar/', views.categoria_editar, name='categoria_editar'),

    # Productos
    path('productos/', views.productos_lista, name='productos_lista'),
    path('productos/nuevo/', views.producto_crear, name='producto_crear'),
    path('productos/<int:pk>/editar/', views.producto_editar, name='producto_editar'),

    # Créditos
    path('creditos/', views.creditos, name='creditos'),
]
