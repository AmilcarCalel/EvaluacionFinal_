from django.shortcuts import render, redirect, get_object_or_404
from .models import Categoria, Producto
from .forms import CategoriaForm, ProductoForm


def home(request):
    return render(request, 'home.html')


# --------- CATEGORÍAS ---------

def categorias_lista(request):
    categorias = Categoria.objects.all()
    return render(request, 'categorias/lista.html', {'categorias': categorias})


def categoria_crear(request):
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('categorias_lista')
    else:
        form = CategoriaForm()
    return render(request, 'categorias/form.html', {'form': form, 'accion': 'Nueva categoría'})


def categoria_editar(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        form = CategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            return redirect('categorias_lista')
    else:
        form = CategoriaForm(instance=categoria)
    return render(request, 'categorias/form.html', {'form': form, 'accion': 'Editar categoría'})


# --------- PRODUCTOS ---------

def productos_lista(request):
    productos = Producto.objects.select_related('categoria').all()
    return render(request, 'productos/lista.html', {'productos': productos})


def producto_crear(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('productos_lista')
    else:
        form = ProductoForm()
    return render(request, 'productos/form.html', {'form': form, 'accion': 'Nuevo producto'})


def producto_editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('productos_lista')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'productos/form.html', {'form': form, 'accion': 'Editar producto'})


# --------- CRÉDITOS ---------

def creditos(request):
    return render(request, 'creditos.html')
